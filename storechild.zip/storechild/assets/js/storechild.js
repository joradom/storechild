/* storechild.js */

(function() {

}).call( this );