<?php
/**
 * Storechild hooks
 *
 * @package storechild
 */

add_action( 'init', 'storechild_hooks' );

/**
 * Add and remove Storechild/Storefront functions.
 *
 * @return void
 */
function storechild_hooks() {

}
