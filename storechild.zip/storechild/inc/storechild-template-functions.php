<?php
/**
 * Storechild template functions.
 *
 * @package storechild
 */
